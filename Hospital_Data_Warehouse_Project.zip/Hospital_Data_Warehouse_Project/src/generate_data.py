from pathlib import Path
import csv
import random
from datetime import date, timedelta

random.seed(42)
OUT = Path(__file__).resolve().parents[1] / "data" / "raw"
OUT.mkdir(parents=True, exist_ok=True)

patients = []
for i in range(1, 101):
    patients.append({
        "patient_id": f"P{i:04d}",
        "patient_name": f"Patient {i}",
        "gender": random.choice(["Male","Female"]),
        "age": random.randint(5, 85),
        "city": random.choice(["Hyderabad","Warangal","Khammam","Vijayawada","Nalgonda"])
    })

doctors = []
deps = ["Cardiology","General Medicine","Orthopedics","Neurology","Pediatrics"]
for i in range(1, 21):
    dep = deps[(i-1) % len(deps)]
    doctors.append({
        "doctor_id": f"D{i:03d}",
        "doctor_name": f"Dr. Doctor {i}",
        "department": dep
    })

diseases = ["Fever","Diabetes","Hypertension","Fracture","Migraine","Asthma","Gastritis"]
meds = ["Paracetamol","Metformin","Amlodipine","Amoxicillin","Omeprazole","Salbutamol"]

def write(name, rows):
    with open(OUT/name, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=rows[0].keys())
        w.writeheader()
        w.writerows(rows)

write("patients.csv", patients)
write("doctors.csv", doctors)

visits = []
billing = []
labs = []
pharmacy = []
appointments = []

start = date(2025,1,1)
for i in range(1, 1001):
    dt = start + timedelta(days=random.randint(0, 364))
    p = random.choice(patients)
    d = random.choice(doctors)
    disease = random.choice(diseases)
    visit_id = f"V{i:05d}"
    visits.append({
        "visit_id": visit_id, "patient_id": p["patient_id"],
        "doctor_id": d["doctor_id"], "visit_date": dt.isoformat(),
        "disease": disease, "branch": random.choice(["Main","North","South"])
    })
    amount = round(random.uniform(300, 8000),2)
    billing.append({
        "bill_id": f"B{i:05d}", "visit_id": visit_id,
        "patient_id": p["patient_id"], "bill_date": dt.isoformat(),
        "amount": amount, "payment_method": random.choice(["Cash","UPI","Card","Insurance"])
    })
    if random.random() < 0.75:
        labs.append({
            "lab_id": f"L{i:05d}", "visit_id": visit_id,
            "patient_id": p["patient_id"], "test_name": random.choice(["CBC","Lipid Profile","Blood Sugar","X-Ray","MRI"]),
            "test_date": dt.isoformat(), "result_value": round(random.uniform(5, 250),2),
            "status": random.choice(["Normal","Normal","Abnormal"])
        })
    if random.random() < 0.70:
        pharmacy.append({
            "sale_id": f"S{i:05d}", "visit_id": visit_id,
            "patient_id": p["patient_id"], "medication": random.choice(meds),
            "sale_date": dt.isoformat(), "quantity": random.randint(1,6),
            "amount": round(random.uniform(50,1500),2)
        })
    appointments.append({
        "appointment_id": f"A{i:05d}", "patient_id": p["patient_id"],
        "doctor_id": d["doctor_id"], "appointment_date": dt.isoformat(),
        "status": random.choice(["Completed","Completed","Cancelled","Scheduled"])
    })

write("visits.csv", visits)
write("billing.csv", billing)
write("lab_tests.csv", labs)
write("pharmacy_sales.csv", pharmacy)
write("appointments.csv", appointments)

# Add a small duplicate to demonstrate ETL deduplication.
with open(OUT/"visits.csv", "a", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=visits[0].keys())
    w.writerow(visits[0])

print(f"Generated source files in {OUT}")
