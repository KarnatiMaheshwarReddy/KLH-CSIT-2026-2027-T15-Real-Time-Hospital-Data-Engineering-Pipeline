from pathlib import Path
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, to_date, year, month, quarter, dayofmonth, date_format, monotonically_increasing_id
from sqlalchemy import create_engine, text
import pandas as pd
import sys
sys.path.append(str(Path(__file__).resolve().parent))
from config import MYSQL_URL

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"

spark = (
    SparkSession.builder
    .appName("HospitalDataWarehouseETL")
    .master("local[*]")
    .config("spark.sql.legacy.timeParserPolicy", "LEGACY")
    .getOrCreate()
)

engine = create_engine(MYSQL_URL)

def clean(df):
    # Remove exact duplicates and standardize text fields.
    df = df.dropDuplicates()
    for c in df.columns:
        if df.schema[c].dataType.simpleString() == "string":
            df = df.withColumn(c, col(c).cast("string"))
    return df

def load_pandas(df, table):
    pdf = df.toPandas()
    pdf.to_sql(table, engine, if_exists="append", index=False, method="multi", chunksize=1000)

# Recreate warehouse tables.
with engine.begin() as conn:
    sql = (ROOT/"sql/01_create_database.sql").read_text(encoding="utf-8")
    for statement in sql.split(";"):
        statement = statement.strip()
        if statement:
            conn.execute(text(statement))

patients = clean(spark.read.option("header", True).option("inferSchema", True).csv(str(RAW/"patients.csv")))
doctors = clean(spark.read.option("header", True).option("inferSchema", True).csv(str(RAW/"doctors.csv")))
visits = clean(spark.read.option("header", True).option("inferSchema", True).csv(str(RAW/"visits.csv")))
billing = clean(spark.read.option("header", True).option("inferSchema", True).csv(str(RAW/"billing.csv")))
labs = clean(spark.read.option("header", True).option("inferSchema", True).csv(str(RAW/"lab_tests.csv")))
pharmacy = clean(spark.read.option("header", True).option("inferSchema", True).csv(str(RAW/"pharmacy_sales.csv")))
appointments = clean(spark.read.option("header", True).option("inferSchema", True).csv(str(RAW/"appointments.csv")))

visits = visits.withColumn("visit_date", to_date("visit_date"))
billing = billing.withColumn("bill_date", to_date("bill_date"))
labs = labs.withColumn("test_date", to_date("test_date"))
pharmacy = pharmacy.withColumn("sale_date", to_date("sale_date"))
appointments = appointments.withColumn("appointment_date", to_date("appointment_date"))

# Dimension tables.
load_pandas(patients.select("patient_id","patient_name","gender","age","city"), "dim_patient")

dept = doctors.select(col("department").alias("department_name")).dropDuplicates()
load_pandas(dept, "dim_department")

load_pandas(doctors.select("doctor_id","doctor_name","department"), "dim_doctor")

disease = visits.select(col("disease").alias("disease_name")).dropDuplicates()
load_pandas(disease, "dim_disease")

med = pharmacy.select(col("medication").alias("medication_name")).dropDuplicates()
load_pandas(med, "dim_medication")

branch = visits.select(col("branch").alias("branch_name")).dropDuplicates()
load_pandas(branch, "dim_branch")

dates = (
    visits.select(col("visit_date").alias("full_date"))
    .union(billing.select(col("bill_date").alias("full_date")))
    .union(labs.select(col("test_date").alias("full_date")))
    .union(pharmacy.select(col("sale_date").alias("full_date")))
    .union(appointments.select(col("appointment_date").alias("full_date")))
    .dropDuplicates()
    .withColumn("year", year("full_date"))
    .withColumn("quarter", quarter("full_date"))
    .withColumn("month", month("full_date"))
    .withColumn("month_name", date_format("full_date","MMMM"))
    .withColumn("day", dayofmonth("full_date"))
    .withColumn("day_name", date_format("full_date","EEEE"))
    .withColumn("time_key", date_format("full_date","yyyyMMdd").cast("int"))
)
load_pandas(dates.select("time_key","full_date","year","quarter","month","month_name","day","day_name"), "dim_time")

# Read generated surrogate keys from MySQL.
patients_k = pd.read_sql("SELECT patient_key, patient_id FROM dim_patient", engine)
doctors_k = pd.read_sql("SELECT doctor_key, doctor_id, department FROM dim_doctor", engine)
dept_k = pd.read_sql("SELECT department_key, department_name FROM dim_department", engine)
disease_k = pd.read_sql("SELECT disease_key, disease_name FROM dim_disease", engine)
med_k = pd.read_sql("SELECT medication_key, medication_name FROM dim_medication", engine)
branch_k = pd.read_sql("SELECT branch_key, branch_name FROM dim_branch", engine)

# Facts through Spark transformations, then pandas only for database loading.
v = visits.toPandas()
v = v.merge(patients_k, on="patient_id").merge(doctors_k, on="doctor_id")
v = v.merge(dept_k, left_on="department", right_on="department_name")
v = v.merge(disease_k, left_on="disease", right_on="disease_name")
v = v.merge(branch_k, left_on="branch", right_on="branch_name")
v["time_key"] = pd.to_datetime(v["visit_date"]).dt.strftime("%Y%m%d").astype(int)
v["visit_count"] = 1
v[["visit_id","patient_key","doctor_key","department_key","time_key","disease_key","branch_key","visit_count"]].to_sql(
    "fact_patient_visit", engine, if_exists="append", index=False, method="multi"
)

b = billing.toPandas().merge(patients_k, on="patient_id")
b["time_key"] = pd.to_datetime(b["bill_date"]).dt.strftime("%Y%m%d").astype(int)
b[["bill_id","patient_key","time_key","amount","payment_method"]].to_sql(
    "fact_billing", engine, if_exists="append", index=False, method="multi"
)

l = labs.toPandas().merge(patients_k, on="patient_id")
l["time_key"] = pd.to_datetime(l["test_date"]).dt.strftime("%Y%m%d").astype(int)
l[["lab_id","patient_key","time_key","test_name","result_value","status"]].to_sql(
    "fact_lab_test", engine, if_exists="append", index=False, method="multi"
)

p = pharmacy.toPandas().merge(patients_k, on="patient_id").merge(med_k, left_on="medication", right_on="medication_name")
p["time_key"] = pd.to_datetime(p["sale_date"]).dt.strftime("%Y%m%d").astype(int)
p[["sale_id","patient_key","medication_key","time_key","quantity","amount"]].to_sql(
    "fact_pharmacy_sale", engine, if_exists="append", index=False, method="multi"
)

a = appointments.toPandas().merge(patients_k, on="patient_id").merge(doctors_k, on="doctor_id")
a = a.merge(dept_k, left_on="department", right_on="department_name", how="left")
a["time_key"] = pd.to_datetime(a["appointment_date"]).dt.strftime("%Y%m%d").astype(int)
a[["appointment_id","patient_key","doctor_key","department_key","time_key","status"]].to_sql(
    "fact_appointment", engine, if_exists="append", index=False, method="multi"
)

# Save processed outputs for evidence/screenshots.
processed = ROOT/"data"/"processed"
processed.mkdir(exist_ok=True)
visits.write.mode("overwrite").option("header", True).csv(str(processed/"visits_cleaned"))
billing.write.mode("overwrite").option("header", True).csv(str(processed/"billing_cleaned"))
labs.write.mode("overwrite").option("header", True).csv(str(processed/"lab_cleaned"))
pharmacy.write.mode("overwrite").option("header", True).csv(str(processed/"pharmacy_cleaned"))
appointments.write.mode("overwrite").option("header", True).csv(str(processed/"appointments_cleaned"))

spark.stop()
print("ETL completed successfully. MySQL warehouse loaded.")
