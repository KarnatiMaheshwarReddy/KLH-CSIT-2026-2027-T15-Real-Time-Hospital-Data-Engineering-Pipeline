USE hospital_dw;

-- 1. Visits by department
SELECT d.department_name, SUM(f.visit_count) AS visits
FROM fact_patient_visit f
JOIN dim_department d ON f.department_key=d.department_key
GROUP BY d.department_name
ORDER BY visits DESC;

-- 2. Revenue by month
SELECT t.year, t.month, t.month_name, ROUND(SUM(f.amount),2) AS revenue
FROM fact_billing f
JOIN dim_time t ON f.time_key=t.time_key
GROUP BY t.year,t.month,t.month_name
ORDER BY t.year,t.month;

-- 3. Top diseases
SELECT ds.disease_name, SUM(f.visit_count) AS cases
FROM fact_patient_visit f
JOIN dim_disease ds ON f.disease_key=ds.disease_key
GROUP BY ds.disease_name
ORDER BY cases DESC;

-- 4. Doctor performance
SELECT dr.doctor_name, dp.department_name, SUM(f.visit_count) AS visits
FROM fact_patient_visit f
JOIN dim_doctor dr ON f.doctor_key=dr.doctor_key
JOIN dim_department dp ON f.department_key=dp.department_key
GROUP BY dr.doctor_name, dp.department_name
ORDER BY visits DESC;

-- 5. Pharmacy revenue
SELECT m.medication_name, SUM(f.quantity) AS quantity_sold, ROUND(SUM(f.amount),2) AS revenue
FROM fact_pharmacy_sale f
JOIN dim_medication m ON f.medication_key=m.medication_key
GROUP BY m.medication_name
ORDER BY revenue DESC;
