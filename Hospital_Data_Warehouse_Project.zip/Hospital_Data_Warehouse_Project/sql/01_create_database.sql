CREATE DATABASE IF NOT EXISTS hospital_dw;
USE hospital_dw;

DROP TABLE IF EXISTS fact_appointment;
DROP TABLE IF EXISTS fact_pharmacy_sale;
DROP TABLE IF EXISTS fact_lab_test;
DROP TABLE IF EXISTS fact_billing;
DROP TABLE IF EXISTS fact_patient_visit;
DROP TABLE IF EXISTS dim_medication;
DROP TABLE IF EXISTS dim_disease;
DROP TABLE IF EXISTS dim_time;
DROP TABLE IF EXISTS dim_branch;
DROP TABLE IF EXISTS dim_department;
DROP TABLE IF EXISTS dim_doctor;
DROP TABLE IF EXISTS dim_patient;

CREATE TABLE dim_patient (
    patient_key INT AUTO_INCREMENT PRIMARY KEY,
    patient_id VARCHAR(20) UNIQUE,
    patient_name VARCHAR(100),
    gender VARCHAR(20),
    age INT,
    city VARCHAR(100)
);

CREATE TABLE dim_doctor (
    doctor_key INT AUTO_INCREMENT PRIMARY KEY,
    doctor_id VARCHAR(20) UNIQUE,
    doctor_name VARCHAR(100),
    department VARCHAR(100)
);

CREATE TABLE dim_department (
    department_key INT AUTO_INCREMENT PRIMARY KEY,
    department_name VARCHAR(100) UNIQUE
);

CREATE TABLE dim_time (
    time_key INT PRIMARY KEY,
    full_date DATE UNIQUE,
    year INT,
    quarter INT,
    month INT,
    month_name VARCHAR(20),
    day INT,
    day_name VARCHAR(20)
);

CREATE TABLE dim_disease (
    disease_key INT AUTO_INCREMENT PRIMARY KEY,
    disease_name VARCHAR(100) UNIQUE
);

CREATE TABLE dim_medication (
    medication_key INT AUTO_INCREMENT PRIMARY KEY,
    medication_name VARCHAR(100) UNIQUE
);

CREATE TABLE dim_branch (
    branch_key INT AUTO_INCREMENT PRIMARY KEY,
    branch_name VARCHAR(100) UNIQUE
);

CREATE TABLE fact_patient_visit (
    visit_key BIGINT AUTO_INCREMENT PRIMARY KEY,
    visit_id VARCHAR(30) UNIQUE,
    patient_key INT,
    doctor_key INT,
    department_key INT,
    time_key INT,
    disease_key INT,
    branch_key INT,
    visit_count INT DEFAULT 1,
    FOREIGN KEY(patient_key) REFERENCES dim_patient(patient_key),
    FOREIGN KEY(doctor_key) REFERENCES dim_doctor(doctor_key),
    FOREIGN KEY(department_key) REFERENCES dim_department(department_key),
    FOREIGN KEY(time_key) REFERENCES dim_time(time_key),
    FOREIGN KEY(disease_key) REFERENCES dim_disease(disease_key),
    FOREIGN KEY(branch_key) REFERENCES dim_branch(branch_key)
);

CREATE TABLE fact_billing (
    bill_key BIGINT AUTO_INCREMENT PRIMARY KEY,
    bill_id VARCHAR(30) UNIQUE,
    patient_key INT,
    time_key INT,
    amount DECIMAL(12,2),
    payment_method VARCHAR(30),
    FOREIGN KEY(patient_key) REFERENCES dim_patient(patient_key),
    FOREIGN KEY(time_key) REFERENCES dim_time(time_key)
);

CREATE TABLE fact_lab_test (
    lab_key BIGINT AUTO_INCREMENT PRIMARY KEY,
    lab_id VARCHAR(30) UNIQUE,
    patient_key INT,
    time_key INT,
    test_name VARCHAR(100),
    result_value DECIMAL(12,2),
    status VARCHAR(30),
    FOREIGN KEY(patient_key) REFERENCES dim_patient(patient_key),
    FOREIGN KEY(time_key) REFERENCES dim_time(time_key)
);

CREATE TABLE fact_appointment (
    appointment_key BIGINT AUTO_INCREMENT PRIMARY KEY,
    appointment_id VARCHAR(30) UNIQUE,
    patient_key INT,
    doctor_key INT,
    department_key INT,
    time_key INT,
    status VARCHAR(30),
    FOREIGN KEY(patient_key) REFERENCES dim_patient(patient_key),
    FOREIGN KEY(doctor_key) REFERENCES dim_doctor(doctor_key),
    FOREIGN KEY(department_key) REFERENCES dim_department(department_key),
    FOREIGN KEY(time_key) REFERENCES dim_time(time_key)
);

CREATE TABLE fact_pharmacy_sale (
    sale_key BIGINT AUTO_INCREMENT PRIMARY KEY,
    sale_id VARCHAR(30) UNIQUE,
    patient_key INT,
    medication_key INT,
    time_key INT,
    quantity INT,
    amount DECIMAL(12,2),
    FOREIGN KEY(patient_key) REFERENCES dim_patient(patient_key),
    FOREIGN KEY(medication_key) REFERENCES dim_medication(medication_key),
    FOREIGN KEY(time_key) REFERENCES dim_time(time_key)
);

CREATE INDEX idx_visit_time ON fact_patient_visit(time_key);
CREATE INDEX idx_bill_time ON fact_billing(time_key);
CREATE INDEX idx_lab_time ON fact_lab_test(time_key);
CREATE INDEX idx_pharmacy_time ON fact_pharmacy_sale(time_key);
