import streamlit as st
import pandas as pd
import plotly.express as px
from sqlalchemy import create_engine, text
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1] / "src"))
from config import MYSQL_URL

st.set_page_config(page_title="Hospital Data Warehouse", page_icon="🏥", layout="wide")

@st.cache_resource
def get_engine():
    return create_engine(MYSQL_URL)

@st.cache_data(ttl=60)
def query(sql):
    return pd.read_sql(sql, get_engine())

st.title("🏥 Hospital Data Warehouse Dashboard")
st.caption("ETL + PySpark + MySQL Star Schema + Hospital Analytics")

try:
    engine = get_engine()
    with engine.connect() as c:
        c.execute(text("SELECT 1"))
except Exception as e:
    st.error("MySQL is not reachable. Start MySQL/Docker and run the ETL first.")
    st.code("docker compose up -d mysql\npython src/generate_data.py\npython src/etl_pyspark.py\nstreamlit run dashboard/app.py")
    st.stop()

patients = query("SELECT COUNT(*) AS n FROM dim_patient").iloc[0,0]
visits = query("SELECT COALESCE(SUM(visit_count),0) AS n FROM fact_patient_visit").iloc[0,0]
revenue = query("SELECT COALESCE(SUM(amount),0) AS n FROM fact_billing").iloc[0,0]
labs = query("SELECT COUNT(*) AS n FROM fact_lab_test").iloc[0,0]
appointments = query("SELECT COUNT(*) AS n FROM fact_appointment").iloc[0,0]

c1,c2,c3,c4,c5 = st.columns(5)
c1.metric("Patients", f"{patients:,}")
c2.metric("Patient Visits", f"{visits:,}")
c3.metric("Total Revenue", f"₹{revenue:,.0f}")
c4.metric("Lab Tests", f"{labs:,}")
c5.metric("Appointments", f"{appointments:,}")

st.divider()

left,right = st.columns(2)

with left:
    dept = query("""
        SELECT d.department_name, SUM(f.visit_count) visits
        FROM fact_patient_visit f
        JOIN dim_department d ON f.department_key=d.department_key
        GROUP BY d.department_name ORDER BY visits DESC
    """)
    fig = px.bar(dept, x="department_name", y="visits", title="Visits by Department")
    st.plotly_chart(fig, use_container_width=True)

with right:
    disease = query("""
        SELECT d.disease_name, SUM(f.visit_count) cases
        FROM fact_patient_visit f
        JOIN dim_disease d ON f.disease_key=d.disease_key
        GROUP BY d.disease_name ORDER BY cases DESC
    """)
    fig = px.pie(disease, names="disease_name", values="cases", title="Disease Distribution")
    st.plotly_chart(fig, use_container_width=True)

left,right = st.columns(2)

with left:
    revenue_month = query("""
        SELECT CONCAT(t.year,'-',LPAD(t.month,2,'0')) month,
               ROUND(SUM(f.amount),2) revenue
        FROM fact_billing f
        JOIN dim_time t ON f.time_key=t.time_key
        GROUP BY t.year,t.month
        ORDER BY t.year,t.month
    """)
    fig = px.line(revenue_month, x="month", y="revenue", markers=True, title="Monthly Revenue")
    st.plotly_chart(fig, use_container_width=True)

with right:
    doctors = query("""
        SELECT dr.doctor_name, dp.department_name, SUM(f.visit_count) visits
        FROM fact_patient_visit f
        JOIN dim_doctor dr ON f.doctor_key=dr.doctor_key
        JOIN dim_department dp ON f.department_key=dp.department_key
        GROUP BY dr.doctor_name,dp.department_name
        ORDER BY visits DESC LIMIT 10
    """)
    fig = px.bar(doctors, x="visits", y="doctor_name", color="department_name",
                 orientation="h", title="Top Doctors by Visits")
    st.plotly_chart(fig, use_container_width=True)

st.subheader("💊 Pharmacy Performance")
pharmacy = query("""
    SELECT m.medication_name, SUM(f.quantity) quantity_sold,
           ROUND(SUM(f.amount),2) revenue
    FROM fact_pharmacy_sale f
    JOIN dim_medication m ON f.medication_key=m.medication_key
    GROUP BY m.medication_name
    ORDER BY revenue DESC
""")
st.dataframe(pharmacy, use_container_width=True)

st.subheader("📅 Appointment Status")
appointment_status = query("""
    SELECT status, COUNT(*) appointments
    FROM fact_appointment GROUP BY status ORDER BY appointments DESC
""")
st.dataframe(appointment_status, use_container_width=True)

st.subheader("🧪 Laboratory Status")
lab_status = query("""
    SELECT status, COUNT(*) tests
    FROM fact_lab_test GROUP BY status ORDER BY tests DESC
""")
st.dataframe(lab_status, use_container_width=True)

with st.expander("Show warehouse tables"):
    tables = query("""SELECT table_name, table_rows
                      FROM information_schema.tables
                      WHERE table_schema='hospital_dw'
                      ORDER BY table_name""")
    st.dataframe(tables, use_container_width=True)
