@echo off
echo ========================================
echo Hospital Data Warehouse
echo ========================================
echo.
echo 1. Generate source data
python src\generate_data.py
echo.
echo 2. Run PySpark ETL
python src\etl_pyspark.py
echo.
echo 3. Start dashboard
streamlit run dashboard\app.py
pause
