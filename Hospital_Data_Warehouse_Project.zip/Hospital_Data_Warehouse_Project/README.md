# Hospital Data Warehouse – Complete FDE Project

A runnable Fundamentals of Data Engineering project based on the supplied requirements:
- Hospital data from registration, doctors, laboratory, pharmacy, billing and appointments
- ETL: Extract → Clean → Transform → Load
- PySpark processing
- MySQL dimensional warehouse / Star Schema
- SQL analytics
- Streamlit web dashboard

## Architecture

Hospital CSV sources
        ↓
Python + PySpark ETL
        ↓
Cleaning / duplicate removal / missing-value handling
        ↓
MySQL Hospital Data Warehouse
        ↓
Star Schema
        ↓
SQL Analytics
        ↓
Streamlit Dashboard

## Star Schema

Dimensions:
- dim_patient
- dim_doctor
- dim_department
- dim_time
- dim_disease
- dim_medication
- dim_branch

Facts:
- fact_patient_visit
- fact_billing
- fact_lab_test
- fact_pharmacy_sale
- fact_appointment

## Fast setup (Windows)

1. Install Python 3.11+.
2. Install MySQL 8.x.
3. Create the database:
   mysql -u root -p < sql/01_create_database.sql
4. Install packages:
   pip install -r requirements.txt
5. Generate/refresh sample source data:
   python src/generate_data.py
6. Run the ETL:
   python src/etl_pyspark.py
7. Start the website:
   streamlit run dashboard/app.py

Open the address shown by Streamlit, normally:
http://localhost:8501

## MySQL configuration

Default:
- host: localhost
- port: 3306
- database: hospital_dw
- user: root
- password: root

Change these in `src/config.py` or set environment variables:
MYSQL_HOST, MYSQL_PORT, MYSQL_DB, MYSQL_USER, MYSQL_PASSWORD

## If you do not have MySQL yet

Use the included `docker-compose.yml`:
docker compose up -d mysql

Then use:
user: root
password: root
database: hospital_dw

## Important

This project uses synthetic/sample healthcare data for academic demonstration. Do not use real patient information.

## Presentation points

Explain:
1. Multiple hospital operational sources create fragmented data.
2. ETL extracts source files, cleans and standardizes records, and loads the warehouse.
3. Star Schema separates measurable facts from descriptive dimensions.
4. SQL analytics produces hospital KPIs.
5. Streamlit presents the warehouse results as an interactive dashboard.
